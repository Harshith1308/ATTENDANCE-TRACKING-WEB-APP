// This file contains JavaScript functions for the attendance.html page

document.addEventListener('DOMContentLoaded', function() {
    // Initialize date pickers if they exist
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (startDateInput && endDateInput) {
        // Initialize flatpickr for date selection
        flatpickr(startDateInput, {
            dateFormat: "Y-m-d",
            maxDate: "today",
            onChange: function(selectedDates, dateStr) {
                // Update end date min value when start date changes
                endDatePicker.set("minDate", dateStr);
            }
        });
        
        const endDatePicker = flatpickr(endDateInput, {
            dateFormat: "Y-m-d",
            maxDate: "today"
        });
        
        // Set initial min value for end date
        if (startDateInput.value) {
            endDatePicker.set("minDate", startDateInput.value);
        }
    }
    
    // Attendance pie chart on individual session view
    const pieChartCanvas = document.getElementById('attendancePieChart');
    if (pieChartCanvas) {
        // Extract data from the page
        const presentCount = parseInt(document.querySelector('[data-present-count]')?.dataset.presentCount || 0);
        const absentCount = parseInt(document.querySelector('[data-absent-count]')?.dataset.absentCount || 0);
        
        // Create pie chart
        new Chart(pieChartCanvas.getContext('2d'), {
            type: 'pie',
            data: {
                labels: ['Present', 'Absent'],
                datasets: [{
                    data: [presentCount, absentCount],
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.7)', // green
                        'rgba(220, 53, 69, 0.7)'  // red
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    title: {
                        display: true,
                        text: 'Attendance Distribution'
                    }
                }
            }
        });
    }
    
    // Handle image modal for processed images
    const processedImages = document.querySelectorAll('[data-processed-image]');
    if (processedImages.length > 0) {
        processedImages.forEach(img => {
            img.addEventListener('click', function() {
                const imageUrl = this.getAttribute('src');
                const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
                document.getElementById('modalImage').src = imageUrl;
                imageModal.show();
            });
        });
    }
});

/**
 * Load student attendance data for a specific student
 * @param {number} studentId - The ID of the student
 * @param {string} startDate - Start date in YYYY-MM-DD format
 * @param {string} endDate - End date in YYYY-MM-DD format
 */
function loadStudentAttendance(studentId, startDate, endDate) {
    // Show loading indicator
    const attendanceContainer = document.getElementById('studentAttendance');
    attendanceContainer.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Loading attendance data...</p></div>';
    
    // Fetch attendance data
    fetch(`/api/student_attendance/${studentId}?start_date=${startDate}&end_date=${endDate}`)
        .then(response => response.json())
        .then(data => {
            // Create attendance table
            let tableHtml = `
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Session</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            if (data.attendance && data.attendance.length > 0) {
                data.attendance.forEach(record => {
                    const statusClass = record.status === 'present' ? 'success' : 'danger';
                    const statusIcon = record.status === 'present' ? 'check-circle' : 'times-circle';
                    
                    tableHtml += `
                        <tr>
                            <td>${record.date}</td>
                            <td>${record.session_name}</td>
                            <td><span class="text-${statusClass}"><i class="fas fa-${statusIcon} me-1"></i>${record.status}</span></td>
                        </tr>
                    `;
                });
            } else {
                tableHtml += `
                    <tr>
                        <td colspan="3" class="text-center py-3">No attendance records found</td>
                    </tr>
                `;
            }
            
            tableHtml += `
                    </tbody>
                </table>
            `;
            
            attendanceContainer.innerHTML = tableHtml;
        })
        .catch(error => {
            console.error('Error loading student attendance:', error);
            attendanceContainer.innerHTML = '<div class="alert alert-danger">Error loading attendance data. Please try again.</div>';
        });
}
