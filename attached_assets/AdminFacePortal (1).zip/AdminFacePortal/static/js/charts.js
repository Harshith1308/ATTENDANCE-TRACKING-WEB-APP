/**
 * Charts utility functions for the attendance system
 * This file provides reusable chart configuration and utility functions
 */

/**
 * Creates a doughnut chart for attendance summary
 * @param {string} elementId - ID of the canvas element
 * @param {number} presentCount - Number of present students
 * @param {number} absentCount - Number of absent students
 * @param {object} options - Additional chart options
 */
function createAttendanceDoughnutChart(elementId, presentCount, absentCount, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            },
            title: {
                display: true,
                text: 'Attendance Summary'
            }
        },
        cutout: '70%'
    };
    
    // Merge with provided options
    const chartOptions = {...defaultOptions, ...options};
    
    // Create the chart
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Present', 'Absent'],
            datasets: [{
                data: [presentCount, absentCount],
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',  // green
                    'rgba(220, 53, 69, 0.7)'   // red
                ],
                borderColor: [
                    'rgba(40, 167, 69, 1)',
                    'rgba(220, 53, 69, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: chartOptions
    });
}

/**
 * Creates a bar chart for daily attendance trends
 * @param {string} elementId - ID of the canvas element
 * @param {Array} labels - Array of date labels
 * @param {Array} presentData - Array of present student counts
 * @param {Array} absentData - Array of absent student counts
 */
function createAttendanceBarChart(elementId, labels, presentData, absentData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Present',
                    data: presentData,
                    backgroundColor: 'rgba(40, 167, 69, 0.7)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Absent',
                    data: absentData,
                    backgroundColor: 'rgba(220, 53, 69, 0.7)',
                    borderColor: 'rgba(220, 53, 69, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    stacked: true,
                },
                y: {
                    stacked: true,
                    beginAtZero: true
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Daily Attendance'
                }
            }
        }
    });
}

/**
 * Creates a line chart for attendance trends over time
 * @param {string} elementId - ID of the canvas element
 * @param {Array} dates - Array of date labels
 * @param {Array} rateData - Array of attendance rates (percentages)
 */
function createAttendanceTrendChart(elementId, dates, rateData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Attendance Rate (%)',
                data: rateData,
                borderColor: 'rgba(0, 123, 255, 1)',
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Attendance Trend'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Attendance Rate (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                }
            }
        }
    });
}

/**
 * Creates a horizontal bar chart for student attendance comparison
 * @param {string} elementId - ID of the canvas element
 * @param {Array} labels - Array of student identifiers
 * @param {Array} data - Array of attendance percentages
 * @param {string} color - Color for the bars (default: blue)
 */
function createStudentComparisonChart(elementId, labels, data, color = 'rgba(0, 123, 255, 0.7)') {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Attendance Rate (%)',
                data: data,
                backgroundColor: color,
                borderColor: color.replace('0.7', '1'),
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

/**
 * Fetch attendance data for a date range and update a chart
 * @param {string} apiUrl - API endpoint URL
 * @param {string} startDate - Start date (YYYY-MM-DD)
 * @param {string} endDate - End date (YYYY-MM-DD)
 * @param {function} callback - Callback function to handle the data
 */
function fetchAttendanceData(apiUrl, startDate, endDate, callback) {
    const url = `${apiUrl}?start_date=${startDate}&end_date=${endDate}`;
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            callback(null, data);
        })
        .catch(error => {
            console.error('Error fetching attendance data:', error);
            callback(error, null);
        });
}
