/**
 * Upload functionality for the attendance system
 * Handles file uploads, image previews, and form submissions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    const sessionDateInput = document.getElementById('session_date');
    if (sessionDateInput) {
        sessionDateInput.value = today;
    }
    
    // Handle file input for preview
    initializeFileUpload();
    
    // Handle form submission with progress indication
    initializeFormSubmission();
});

/**
 * Initialize file upload functionality with previews
 */
function initializeFileUpload() {
    const fileInput = document.getElementById('files');
    const imagePreview = document.getElementById('imagePreview');
    
    if (!fileInput || !imagePreview) return;
    
    fileInput.addEventListener('change', function() {
        // Clear previous previews
        imagePreview.innerHTML = '';
        
        if (this.files && this.files.length > 0) {
            // Show preview container
            imagePreview.classList.remove('d-none');
            
            // Process each file
            Array.from(this.files).forEach(file => {
                if (!file.type.match('image.*')) {
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    const col = document.createElement('div');
                    col.className = 'col-md-3 col-sm-6';
                    
                    const card = document.createElement('div');
                    card.className = 'card h-100';
                    
                    const img = document.createElement('img');
                    img.className = 'card-img-top';
                    img.src = e.target.result;
                    img.alt = file.name;
                    img.style.height = '150px';
                    img.style.objectFit = 'cover';
                    
                    const cardBody = document.createElement('div');
                    cardBody.className = 'card-body p-2';
                    
                    const fileName = document.createElement('p');
                    fileName.className = 'card-text small text-truncate mb-0';
                    fileName.textContent = file.name;
                    
                    const fileSize = document.createElement('p');
                    fileSize.className = 'card-text small text-muted mb-0';
                    fileSize.textContent = formatFileSize(file.size);
                    
                    cardBody.appendChild(fileName);
                    cardBody.appendChild(fileSize);
                    card.appendChild(img);
                    card.appendChild(cardBody);
                    col.appendChild(card);
                    imagePreview.appendChild(col);
                };
                
                reader.readAsDataURL(file);
            });
        } else {
            // Hide preview container when no files
            imagePreview.classList.add('d-none');
        }
    });
}

/**
 * Initialize form submission with progress indication
 */
function initializeFormSubmission() {
    const uploadForm = document.getElementById('uploadForm');
    const progressBar = document.querySelector('#uploadProgress .progress-bar');
    const uploadProgress = document.getElementById('uploadProgress');
    const submitBtn = document.getElementById('submitBtn');
    
    if (!uploadForm || !progressBar || !uploadProgress || !submitBtn) return;
    
    uploadForm.addEventListener('submit', function(e) {
        // Validate form inputs
        const sessionName = document.getElementById('session_name').value.trim();
        const sessionDate = document.getElementById('session_date').value;
        const filesInput = document.getElementById('files');
        
        if (!sessionName || !sessionDate || filesInput.files.length === 0) {
            // Form validation is handled by HTML5 required attributes
            return;
        }
        
        // Show progress
        uploadProgress.classList.remove('d-none');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...';
        
        // Simulate progress (in a real app with XHR, this would be based on actual upload progress)
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            if (progress > 100) progress = 100;
            
            progressBar.style.width = progress + '%';
            progressBar.setAttribute('aria-valuenow', progress);
            
            if (progress >= 100) {
                clearInterval(interval);
            }
        }, 300);
        
        // We don't prevent default because we want the form to actually submit
    });
}

/**
 * Format file size in a human-readable format
 * @param {number} bytes - File size in bytes
 * @returns {string} Formatted file size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Display validation errors for the upload form
 * @param {Object} errors - Map of field names to error messages
 */
function showUploadErrors(errors) {
    // Clear previous error messages
    const errorElements = document.querySelectorAll('.invalid-feedback');
    errorElements.forEach(el => el.remove());
    
    const fields = document.querySelectorAll('.form-control');
    fields.forEach(field => {
        field.classList.remove('is-invalid');
    });
    
    // Add new error messages
    for (const [field, message] of Object.entries(errors)) {
        const inputElement = document.getElementById(field);
        if (inputElement) {
            inputElement.classList.add('is-invalid');
            
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = message;
            
            inputElement.parentNode.appendChild(errorDiv);
        }
    }
}

/**
 * Reset the upload form
 */
function resetUploadForm() {
    const form = document.getElementById('uploadForm');
    if (form) {
        form.reset();
        
        // Clear image previews
        const imagePreview = document.getElementById('imagePreview');
        if (imagePreview) {
            imagePreview.innerHTML = '';
            imagePreview.classList.add('d-none');
        }
        
        // Reset progress bar
        const uploadProgress = document.getElementById('uploadProgress');
        const progressBar = document.querySelector('#uploadProgress .progress-bar');
        if (uploadProgress && progressBar) {
            uploadProgress.classList.add('d-none');
            progressBar.style.width = '0%';
            progressBar.setAttribute('aria-valuenow', 0);
        }
        
        // Reset submit button
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-camera me-1"></i> Process Attendance';
        }
        
        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        const sessionDateInput = document.getElementById('session_date');
        if (sessionDateInput) {
            sessionDateInput.value = today;
        }
    }
}
